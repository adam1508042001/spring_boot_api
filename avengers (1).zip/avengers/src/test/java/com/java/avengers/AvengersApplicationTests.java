package com.java.avengers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvengersApplicationTests {

	@Test
	void contextLoads() {
	}

}
